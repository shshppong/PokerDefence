using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace HwatuDefence
{
    public enum CardType
    {
        Hwatu
    }

    [CreateAssetMenu(fileName = "Card", menuName = "Card/Card")]

    public class CardData : ScriptableObject
    {
        public CardType typeIndex;
        public List<CardInfo> cardInfos;

        public void OnValidate()
        {
            for(int i = 0; i < cardInfos.Count; i++)
            {
                cardInfos[i].elementName = "[" + ((int)typeIndex * 10000 + i+1) + "]  \t" + cardInfos[i].itemName;
                cardInfos[i].ID = ((int)typeIndex * 10000 + i+1);

                if(cardInfos[i].thumbnailSprites == null && cardInfos[i].sprites.Length > 0)
                    cardInfos[i].thumbnailSprites = cardInfos[i].sprites[0];
            }
        }
        
        // [SerializeField]
        // private List<Sprite> sprites = new List<Sprite>();
        // public List<Sprite> Sprites { get { return sprites; } }
    }
    
}
