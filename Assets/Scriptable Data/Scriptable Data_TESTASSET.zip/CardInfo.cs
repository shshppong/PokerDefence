using System;
using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

namespace HwatuDefence
{
    [System.Serializable]
    public class CardInfo
    {
        [HideInInspector]
        public string elementName;
        public int ID;
        public string itemName;
        public Sprite thumbnailSprites;
        public string description;
        public Sprite[] sprites;
    }


    /*
    [CustomPropertyDrawer(typeof(CardInfo))]
    internal sealed class CardInfoDrawer : PropertyDrawer
    {
        const float imageHeight = 20;
        public override float GetPropertyHeight(SerializedProperty property, GUIContent label)
        {
            if(property.FindPropertyRelative("thumbnailSprite").propertyType == SerializedPropertyType.ObjectReference && 
                (property.FindPropertyRelative("thumbnailSprite").objectReferenceValue as Sprite) != null)
            {
                return EditorGUI.GetPropertyHeight(property, label, true) + imageHeight + 40;
            }
            return EditorGUI.GetPropertyHeight(property, label, true);
        }

        static string GetPath(SerializedProperty property)
        {
            string path = property.propertyPath;
            int index = path.LastIndexOf(",");
            return path.Substring(0, index + 1);
        }

        public override void OnGUI(Rect position, SerializedProperty property, GUIContent label)
        {
            // Draw the normal property field
            EditorGUI.PropertyField(position, property, label, true);

            if(property.FindPropertyRelative("thumbnailSprite").propertyType == SerializedPropertyType.ObjectReference)
            {
                Sprite sprite = property.FindPropertyRelative("thumbnailSprite").objectReferenceValue as Sprite;
                if(sprite != null)
                {
                    position.y += EditorGUI.GetPropertyHeight(property, label, true) + 5;
                    position.height = imageHeight;

                    GUI.DrawTexture(position, sprite.texture, ScaleMode.ScaleToFit);
                    //DrawTexturePreview(position, sprite);
                }
            }
            
        }

        private void DrawTexturePreview(Rect position, Sprite sprite)
        {
            Vector2 fullSize = new Vector2(sprite.texture.width, sprite.texture.height);
            Vector2 size = new Vector2(sprite.textureRect.width, sprite.textureRect.height);
            
            Rect coords = sprite.textureRect;
            coords.x /= fullSize.x;
            coords.width /= fullSize.x;
            coords.y /= fullSize.y;
            coords.height /= fullSize.y;

            Vector2 ratio;
            ratio.x = position.width / size.x;
            ratio.y = position.height / size.y;
            float minRatio = Mathf.Min(ratio.x, ratio.y);

            Vector2 center = position.center;
            position.width = size.x * minRatio;
            position.height = size.y * minRatio;

            
        }
    }
    */
}
